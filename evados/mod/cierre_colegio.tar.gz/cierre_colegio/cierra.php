<? 
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=latin1" />
<title>Documento sin t&iacute;tulo</title>
<script type="text/javascript">

$(document).ready(function(){ // Script para cargar al inicio del modulo
inicio();
});

function inicio(){
	var parametros = "funcion=1";

	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		//url:'cont_doc.php',
		data:parametros,
		type:'POST',
		success:function(data){
			//alert(data);
			if(data==0){
				alert("Error de Sistema");
			}else{
				$('#proceso_cierre1').html(data);
			}
		}
	})	
}
function director(){
 var parametros ="funcion=2";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				UTP(); 
			}
		}
	})
}
function UTP(){
 var parametros ="funcion=3";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				inspector();
			}
		}
	})
}
function inspector(){
 var parametros ="funcion=4";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				docente();
			}
		}
	})
}
function docente(){
 var parametros ="funcion=5";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				orientador()
			}
		}
	})
}
function orientador(){
 var parametros ="funcion=6";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				capellan();
			}
		}
	})
}
function capellan(){
 var parametros ="funcion=7";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
				profesor();
			}
		}
	})
}
function profesor(){
 var parametros ="funcion=8";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Evaluado");
			}else{
				$('#proceso_cierre1').html(data);
			}
		}
	})
}
function cargardatos(){
 var parametros ="funcion=9";
 	$.ajax({
		url:'mod/cierre_colegio/cont_cierra.php',
		data:parametros,
		type:'POST',
		success:function(data){
			if(data==0){
				alert("Error en Cierre Conceptos");
			}else{
				$('#proceso_cierre1').html(data);
				director();
			}
		}
	})
}
</script>
<style>
#bloques{ margin:10px; margin-top:40px; margin-left:10%; text-align:left; width:80%; }
</style>
</head>

<body>
<div id="bloques" align="center"  >

<fieldset>
<legend>PROCESO CIERRE DE COLEGIO</legend>
<div id="nombre_bloque">
<table width="100%" border="0" cellspacing="5" cellpadding="5" style="border-collapse:collapse">
  <tr>
    <td width="18%" class="textonegrita">A&ntilde;o Academico</td>
    <td width="82%">2012</td>
  </tr>
  <tr>
    <td class="textonegrita">Periodo </td>
    <td>Segundo Ciclo</td>
  </tr>
  <tr>
    <td class="textonegrita">Fecha</td>
    <td>&nbsp;<?=date("d-m-Y");?></td>
  </tr>
</table>	

<div id="bottoncontrol" >
<br>																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																<input name="creardoc" type="button" onClick="cargardatos()" value="CERRAR PROCESO" class="botonXX"/>
</div>

</div>
<br />

<div id="proceso_cierre1">&nbsp;</div>
</fieldset>
</div>
</body>
</html>
