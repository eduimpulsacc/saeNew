#!/bin/bash
/opt/OpenOffice.org1.1.1/program/python /var/www/localhost/htdocs/pfc/phpdocwriter/conf/export.py $1 $2