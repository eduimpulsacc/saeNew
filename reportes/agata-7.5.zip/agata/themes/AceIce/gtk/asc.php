<?

for ($x=0; $x<=255; $x++)
{
  echo $x . " : " . chr($x) . "\n";

}
?>
